Configuration ContosoWebsite
{
  Powershell.exe -File C:\Program Files\WindowsPowerShell\Modules\scripts\createMof.ps1
  Powershell.exe -File C:\Program Files\WindowsPowerShell\Modules\scripts\setPull.ps1
} 