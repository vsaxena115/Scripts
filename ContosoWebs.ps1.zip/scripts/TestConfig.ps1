configuration TestConfig
{
Powershell.exe -File C:\Program Files\WindowsPowerShell\Modules\createMof.ps1
Powershell.exe -File C:\Program Files\WindowsPowerShell\Modules\setPull.ps1
}TestConfig